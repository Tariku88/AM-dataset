import numpy as np
import pandas as pd
import keras
import tensorflow as tf
from keras.utils import to_categorical
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report, ConfusionMatrixDisplay

#from models import classifier
from models import clf_builder

# load the data we have saved before in training.py line 35-38
X_train = np.load(r'.\X_train_2023_1212_1614.npy')
X_test = np.load(r'.\X_test_2023_1212_1614.npy')
y_train = np.load(r'.\y_train_2023_1212_1614.npy')
y_test = np.load(r'.\y_test_2023_1212_1614.npy')

# shuffle the data (optional)
random_state = np.random.get_state()
np.random.shuffle(X_test)
np.random.set_state(random_state)
np.random.shuffle(y_test)

random_state = np.random.get_state()
np.random.shuffle(X_train)
np.random.set_state(random_state)
np.random.shuffle(y_train)

# load the model

#clf = tf.keras.models.load_model(r'nn2_final.h5')
clf = clf_builder((6, 10, 10, 5))()
clf.load_weights(r'nn1_final.h5')

print(r'test_acc: ', clf.evaluate(X_test, to_categorical(y_test, num_classes=5)))
print(r'train_acc: ', clf.evaluate(X_train, to_categorical(y_train, num_classes=5)))

# Confusion matrix plot ##
# Get the predictions
val_pred_DNN1 = np.argmax(clf.predict(X_test), axis=-1)

print(classification_report(y_test,val_pred_DNN1))

# Calculate the confusion matrix
cm = confusion_matrix(y_test, val_pred_DNN1)
print(cm)
display = ConfusionMatrixDisplay(cm)
display.plot()
plt.show()

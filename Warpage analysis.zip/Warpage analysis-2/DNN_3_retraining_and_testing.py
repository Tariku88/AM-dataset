
import numpy as np
import pickle
import joblib
#from sklearn.externals import joblib

from models import clf_builder
#from models import classifier

from keras.callbacks import ModelCheckpoint
from keras.utils import to_categorical
import matplotlib.pyplot as plt

# hyper-parameter settings for neural network training
TRAINING_EPOCHS = 50
BATCH_SIZE = 24

nn3_val_acc = []

nn3_train_acc = []

# load the data we have saved before in training.py line 35-38
X_train = np.load(r'.\X_train_2023_1212_1614.npy')
X_test = np.load(r'.\X_test_2023_1212_1614.npy')
y_train = np.load(r'.\y_train_2023_1212_1614.npy')
y_test = np.load(r'.\y_test_2023_1212_1614.npy')

# shuffle the data (optional)
random_state = np.random.get_state()
np.random.shuffle(X_test)
np.random.set_state(random_state)
np.random.shuffle(y_test)

random_state = np.random.get_state()
np.random.shuffle(X_train)
np.random.set_state(random_state)
np.random.shuffle(y_train)


# re-train the model using `X_train` and `y_train`
clf = clf_builder((6, 10, 10, 10, 10, 5))()
checkpoint3 = ModelCheckpoint(r'.\nn3_final' + r'.h5', save_best_only=True)
history3 = clf.fit(X_train, to_categorical(y_train, num_classes=5), batch_size=BATCH_SIZE,
                   epochs=TRAINING_EPOCHS, callbacks=[checkpoint3],
                   validation_data=(X_test, to_categorical(y_test, num_classes=5)))
nn3_val_acc.append(max(history3.history['val_accuracy']))

nn3_train_acc.append(max(history3.history['accuracy']))

with open('/trainHistoryDict', 'wb') as file_pi:
    pickle.dump(history3.history, file_pi)

print(r'nn3_test_acc: ', nn3_val_acc)
print(r'nn3_train_acc: ', nn3_train_acc)







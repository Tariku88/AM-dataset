#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
Created on 2020/9/10 15:39

@author: GoHome

Visualize the training and testing results here.
"""
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

#from sklearn.externals import joblib
import joblib
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay

# load the data we have saved before in training.py line 35-38
X_train = np.load(r'.\X_train_2023_1212_1614.npy')
X_test = np.load(r'.\X_test_2023_1212_1614.npy')
y_train = np.load(r'.\y_train_2023_1212_1614.npy')
y_test = np.load(r'.\y_test_2023_1212_1614.npy')

# shuffle the data (optional)
random_state = np.random.get_state()
np.random.shuffle(X_test)
np.random.set_state(random_state)
np.random.shuffle(y_test)

random_state = np.random.get_state()
np.random.shuffle(X_train)
np.random.set_state(random_state)
np.random.shuffle(y_train)

# load the model
rnd_clf = joblib.load(r'rnd_clf_final.model')

print(rnd_clf.score(X_test, y_test))
print(rnd_clf.score(X_train, y_train))


# Confusion matrix plot ##
# Get the predictions
val_pred_RF = rnd_clf.predict(X_test)

print(classification_report(y_test,val_pred_RF))

# Calculate the confusion matrix
cm = confusion_matrix(y_test, val_pred_RF)
print(cm)
display = ConfusionMatrixDisplay(cm)
display.plot()
plt.show()
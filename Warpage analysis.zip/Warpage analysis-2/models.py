#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
Created on 2020/9/4 17:53

@author: GoHome

Neural network models
"""
from keras.models import Sequential
from keras.layers import InputLayer, Dense, BatchNormalization


def classifier(shape_info):
    """
    Construct neural network with given shape information.
    :param shape_info: a tuple that defines the number of neurons in each layer, e.g., (4, 10, 5)
    :return: the classifier
    """
    # add input layer
    layers = [InputLayer(input_shape=(shape_info[0], ))]
    # add the rest layers
    for shape in shape_info[1:-1]:
        layers.append(BatchNormalization())
        layers.append(Dense(units=shape, activation='relu', kernel_initializer='he_normal'))
    layers.append(BatchNormalization())
    layers.append(Dense(units=shape_info[-1], activation='softmax', kernel_initializer='he_normal'))
    # create the model
    model = Sequential(layers)
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    model.summary()
    return model


def clf_builder(shape_info):
    # classifier builder
    # the definition of the function `clf` is the same as the function `classifier`
    def clf():
        # add input layer
        layers = [InputLayer(input_shape=(shape_info[0],))]
        # add the rest layers
        for shape in shape_info[1:-1]:
            layers.append(BatchNormalization())
            layers.append(Dense(units=shape, activation='relu', kernel_initializer='he_normal'))
        layers.append(BatchNormalization())
        layers.append(Dense(units=shape_info[-1], activation='softmax', kernel_initializer='he_normal'))
        # create the model
        model = Sequential(layers)
        model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
        return model
    return clf

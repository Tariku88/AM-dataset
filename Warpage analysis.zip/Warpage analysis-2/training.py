#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
Created on 2020/9/4 17:22

@author: GoHome

Training and choose the best model using 5-fold cross-validation.
"""
import numpy as np

from keras.callbacks import ModelCheckpoint
from keras.utils import to_categorical

import joblib
#from sklearn.externals import joblib
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression

from models import clf_builder
from utilities import load_data

# file path to load the data
DATA_PATH = r'.\data.xlsx'

# hyper-parameter settings for neural network training
TRAINING_EPOCHS = 80
BATCH_SIZE = 16

# load the data
# `X_train_full` and `y_train_full` are lists of 5 ndarrays that contain data for 5-fold cross-validation
# `X_test` and `y_test` are ndarrays
X_train_full, X_test, y_train_full, y_test = load_data(DATA_PATH, one_hot=False)

# save the divided data
np.save(r'.\X_train_2023_1212_1614.npy', np.vstack(X_train_full))
np.save(r'.\y_train_2023_1212_1614.npy', np.hstack(y_train_full))
np.save(r'.\X_test_2023_1212_1614.npy', X_test)
np.save(r'.\y_test_2023_1212_1614.npy', y_test)

# lists to record validation accuracy for each model
nn1_valid_acc = []
nn2_valid_acc = []
nn3_valid_acc = []
svm_valid_acc = []
tree_valid_acc = []
rf_valid_acc = []
lg_valid_acc = []

# do 5 fold cross-validation
for i in range(5):
    # generate the training data and validation data
    X_train = np.vstack([X_train_full[j] for j in range(5) if j is not i])
    X_valid = X_train_full[i]
    y_train = np.hstack([y_train_full[j] for j in range(5) if j is not i])
    y_valid = y_train_full[i]

    # shuffle the training data
    random_state = np.random.get_state()
    np.random.shuffle(X_train)
    np.random.set_state(random_state)
    np.random.shuffle(y_train)

    # model construction and model training

    # 1 neural network
    # three kinds of architectures, for each fold, save the model weight as 'nnj_i.h5',
    # j = 1, 2, 3 stands for model index, and i = 0, 1, 2, 3, 4 stands for fold index
    # we can load the model by:
    #       from models import classifier
    #       clf = classifier(shape_info)
    #       clf.load_weights(r'nnj_i.h5')
    clf = clf_builder((6, 10, 10, 5))()
    checkpoint1 = ModelCheckpoint(r'.\nn1_' + repr(i) + r'.h5', save_best_only=True)
    history1 = clf.fit(X_train, to_categorical(y_train, num_classes=5), batch_size=BATCH_SIZE,
                       epochs=TRAINING_EPOCHS, callbacks=[checkpoint1],
                       validation_data=(X_valid, to_categorical(y_valid, num_classes=5)))
    # record the validation accuracy
    nn1_valid_acc.append(max(history1.history['val_accuracy']))

    clf = clf_builder((6, 10, 10, 10, 5))()
    checkpoint2 = ModelCheckpoint(r'.\nn2_' + repr(i) + r'.h5', save_best_only=True)
    history2 = clf.fit(X_train, to_categorical(y_train, num_classes=5), batch_size=BATCH_SIZE,
                       epochs=TRAINING_EPOCHS, callbacks=[checkpoint2],
                       validation_data=(X_valid, to_categorical(y_valid, num_classes=5)))
    nn2_valid_acc.append(max(history2.history['val_accuracy']))

    clf = clf_builder((6, 10, 10, 10, 10, 5))()
    checkpoint3 = ModelCheckpoint(r'.\nn3_' + repr(i) + r'.h5', save_best_only=True)
    history3 = clf.fit(X_train, to_categorical(y_train, num_classes=5), batch_size=BATCH_SIZE,
                       epochs=TRAINING_EPOCHS, callbacks=[checkpoint3],
                       validation_data=(X_valid, to_categorical(y_valid, num_classes=5)))
    nn3_valid_acc.append(max(history3.history['val_accuracy']))

    # 2 support vector machine
    svm_clf = SVC(C=1, kernel='rbf', degree=5, gamma='scale')
    svm_clf.fit(X_train, y_train)
    # record the validation accuracy
    svm_valid_acc.append(svm_clf.score(X_valid, y_valid))
    # save the model as 'svm_clf_i.model', i = 0, 1, 2, 3, 4 stands for fold index
    # we can load the model by:
    #       from sklearn.externals import joblib
    #       rnd_clf = joblib.load('final_rnd_clf.model')
    joblib.dump(svm_clf, r'svm_clf_' + repr(i) + r'.model')

    # 3 decision tree
    tree_clf = DecisionTreeClassifier()
    tree_clf.fit(X_train, y_train)
    tree_valid_acc.append(tree_clf.score(X_valid, y_valid))
    joblib.dump(tree_clf, r'tree_clf_' + repr(i) + r'.model')

    # 4 random forest
    rnd_clf = RandomForestClassifier(n_estimators=1000, n_jobs=-1)
    rnd_clf.fit(X_train, y_train)
    rf_valid_acc.append(rnd_clf.score(X_valid, y_valid))
    joblib.dump(rnd_clf, r'rnd_clf_' + repr(i) + r'.model')

    # 5 logistic regression
    softmax_reg = LogisticRegression(penalty='l2', multi_class="multinomial", solver="lbfgs", C=10, max_iter=1000)
    softmax_reg.fit(X_train, y_train)
    lg_valid_acc.append(softmax_reg.score(X_valid, y_valid))
    joblib.dump(softmax_reg, r'softmax_reg_' + repr(i) + r'.model')

# print the validation accuracy for each model
print(r'nn1_valid_acc:', nn1_valid_acc)
print(r'nn2_valid_acc:', nn2_valid_acc)
print(r'nn3_valid_acc:', nn3_valid_acc)
print(r'svm_valid_acc:', svm_valid_acc)
print(r'tree_valid_acc:', tree_valid_acc)
print(r'rf_valid_acc:', rf_valid_acc)
print(r'lg_valid_acc:', lg_valid_acc)

# print mean validation accuracy for each model
print(r'mean validation acc:')
print(sum(nn1_valid_acc) / 5, sum(nn2_valid_acc) / 5, sum(nn3_valid_acc) / 5,
      sum(svm_valid_acc) / 5, sum(tree_valid_acc) / 5,
      sum(rf_valid_acc) / 5, sum(lg_valid_acc) / 5)

import numpy as np
import joblib
#from sklearn.externals import joblib
from sklearn.linear_model import LogisticRegression

# load the data we have saved before in training.py line 35-38
X_train = np.load(r'.\X_train_2023_1212_1614.npy')
X_test = np.load(r'.\X_test_2023_1212_1614.npy')
y_train = np.load(r'.\y_train_2023_1212_1614.npy')
y_test = np.load(r'.\y_test_2023_1212_1614.npy')

# shuffle the data (optional)
random_state = np.random.get_state()
np.random.shuffle(X_test)
np.random.set_state(random_state)
np.random.shuffle(y_test)

random_state = np.random.get_state()
np.random.shuffle(X_train)
np.random.set_state(random_state)
np.random.shuffle(y_train)

# re-train the model using `X_train` and `y_train`
softmax_reg = LogisticRegression(penalty='l2', multi_class="multinomial", solver="lbfgs", C=10, max_iter=1000)
softmax_reg.fit(X_train, y_train)

# test the model
print(softmax_reg.score(X_test, y_test))
print(softmax_reg.score(X_train, y_train ))

# save the final model
joblib.dump(softmax_reg, 'softmax_reg_final.model')

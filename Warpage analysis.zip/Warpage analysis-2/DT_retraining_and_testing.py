import numpy as np
import joblib
#from sklearn.externals import joblib
from sklearn.tree import DecisionTreeClassifier

# load the data we have saved before in training.py line 35-38
X_train = np.load(r'.\X_train_2023_1212_1614.npy')
X_test = np.load(r'.\X_test_2023_1212_1614.npy')
y_train = np.load(r'.\y_train_2023_1212_1614.npy')
y_test = np.load(r'.\y_test_2023_1212_1614.npy')

# shuffle the data (optional)
random_state = np.random.get_state()
np.random.shuffle(X_test)
np.random.set_state(random_state)
np.random.shuffle(y_test)

random_state = np.random.get_state()
np.random.shuffle(X_train)
np.random.set_state(random_state)
np.random.shuffle(y_train)

# re-train the model using `X_train` and `y_train`
tree_clf = DecisionTreeClassifier()
tree_clf.fit(X_train, y_train)

# test the model
print(tree_clf.score(X_test, y_test))
print(tree_clf.score(X_train, y_train ))

# save the final model
joblib.dump(tree_clf, 'tree_clf_final.model')

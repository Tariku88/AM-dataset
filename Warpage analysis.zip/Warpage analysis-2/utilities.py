#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
Created on 2020/9/4 20:01

@author: GoHome
"""
import numpy as np
import pandas as pd
from keras.utils import to_categorical

def load_data(data_path, one_hot=True):
    """
    Pre-process the data and prepare for 5-fold cross-validation.
    :param data_path: file path of the data
    :param one_hot: bool, one-hot code the label or not
    :return: X_train: list of 5 ndarrays
             y_train: list of 5 ndarrays
             X_test: ndarray
             y_test: ndarray
             When do cross-validation, if use X_train[0] as the validation data,
             then the training data is np.vstack(X_train[1:5]).
    """
    # load the data
    data = pd.read_excel(data_path)
    # sort the data by 'connection status'
    data = data.sort_values(by='Warpage indicator', ascending=True)

    # record the number of samples in each level
    # the results are 532, 230, 163, 162, 113
    num = []
    for i in range(5):
        num.append(len([s for s in data['Warpage indicator'] if s == i]))

    # read all data to `X`, `y`
    X = []
    for i in range(len(data)):
        # normalize the data to be within [0, 1]
        X.append([data['Material type'][i] / max(data['Material type']),
                  data['Infill amount'][i] / max(data['Infill amount']),
                  data['Toolpath pattern'][i] / max(data['Toolpath pattern']),
                  data['Layer height'][i] / max(data['Layer height']),
                  data['Print speed'][i] / max(data['Print speed']),
                  data['Extrusion temprature'][i] / max(data['Extrusion temprature'])])
    X = np.asarray(X)
    y = np.asarray(data['Warpage indicator'])
    if one_hot is True:
        y = to_categorical(y, num_classes=5)

    # record the index for each level, e.g., the data of level 1 are X[index[0]:index[1]]
    index = [0, num[0], num[0] + num[1], num[0] + num[1] + num[2], num[0] + num[1] + num[2] + num[3], len(X)]

    # use `X_full` and `y_full` to record the data of each level
    # `X_full` will be a list of ndarrays, e.g., X_full[0] is the data of level 1, which is X[index[0]:index[1]]
    X_full = []
    y_full = []

    # `X_train` contains 5 parts of the data for cross-validation, 80% in total
    # `X_test` is the testing data, 20%
    X_train = [[], [], [], [], []]
    X_test = []
    y_train = [[], [], [], [], []]
    y_test = []

    # for each level, construct `X_full`, `X_train`, `X_test` and `y_full`, `y_train`, `y_test`
    for i in range(5):
        # for each level, append the data
        X_full.append(X[index[i]:index[i + 1]])
        y_full.append(y[index[i]:index[i + 1]])

        # shuffle the data of each level
        # we do not need to shuffle the label y here, because the labels are the same for the same level
        np.random.shuffle(X_full[i])

        # X_train : X_test = 16% * 5 : 20%

        # first construct `X_train` and `y_train`
        # we use 5 fold cross-validation, and here we construct each fold
        for j in range(5):
            # append 16% of the X_full[i] to each fold
            X_train[j].append(X_full[i][int(0.16 * j * len(X_full[i])):int(0.16 * (j + 1) * len(X_full[i]))])
            y_train[j].append(y_full[i][int(0.16 * j * len(y_full[i])):int(0.16 * (j + 1) * len(y_full[i]))])

        # then construct `X_test`
        X_test.append(X_full[i][int(0.8 * len(X_full[i])):])
        y_test.append(y_full[i][int(0.8 * len(y_full[i])):])

    # transform `X_test`, `y_test` to ndarrays
    # and transform `X_train`, `y_train` to list of 5 ndarrays
    X_test = np.vstack(X_test)
    if one_hot is True:
        y_test = np.vstack(y_test)
    else:
        y_test = np.hstack(y_test)
    for j in range(5):
        X_train[j] = np.vstack(X_train[j])
        if one_hot is True:
            y_train[j] = np.vstack(y_train[j])
        else:
            y_train[j] = np.hstack(y_train[j])

    return X_train, X_test, y_train, y_test

#!/usr/bin/env python 
# -*- coding:utf-8 -*-
"""
Created on 2020/9/6 19:33

@author: GoHome

Re-train the model that has the best validation accuracy with all training data and test it.
"""
import numpy as np
import joblib
#from sklearn.externals import joblib
from sklearn.ensemble import RandomForestClassifier

# load the data we have saved before in training.py line 35-38
X_train = np.load(r'.\X_train_2023_1212_1614.npy')
X_test = np.load(r'.\X_test_2023_1212_1614.npy')
y_train = np.load(r'.\y_train_2023_1212_1614.npy')
y_test = np.load(r'.\y_test_2023_1212_1614.npy')

# shuffle the data (optional)
random_state = np.random.get_state()
np.random.shuffle(X_test)
np.random.set_state(random_state)
np.random.shuffle(y_test)

random_state = np.random.get_state()
np.random.shuffle(X_train)
np.random.set_state(random_state)
np.random.shuffle(y_train)

# re-train the model using `X_train` and `y_train`
rnd_clf = RandomForestClassifier(n_estimators=1000, n_jobs=-1)
rnd_clf.fit(X_train, y_train)

# test the model
print(rnd_clf.score(X_test, y_test))
print(rnd_clf.score(X_train, y_train ))

# save the final model
joblib.dump(rnd_clf, 'rnd_clf_final.model')

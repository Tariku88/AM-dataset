"""
Created on 2020/9/10 15:39

@author: GoHome

Visualize the training and testing results here.
"""
#import os
#os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"


import numpy as np
import pandas as pd
import pickle
import keras
import tensorflow as tf
from keras.utils import to_categorical
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
from sklearn.metrics import confusion_matrix, classification_report, ConfusionMatrixDisplay

#from models import classifier
from models import clf_builder

# load the data we have saved before in training.py line 35-38
X_train = np.load(r'.\X_train_2023_1212_1614.npy')
X_test = np.load(r'.\X_test_2023_1212_1614.npy')
y_train = np.load(r'.\y_train_2023_1212_1614.npy')
y_test = np.load(r'.\y_test_2023_1212_1614.npy')

# shuffle the data (optional)
random_state = np.random.get_state()
np.random.shuffle(X_test)
np.random.set_state(random_state)
np.random.shuffle(y_test)

random_state = np.random.get_state()
np.random.shuffle(X_train)
np.random.set_state(random_state)
np.random.shuffle(y_train)

# load the model

#clf = tf.keras.models.load_model(r'nn3_final.h5')
clf = clf_builder((6, 10, 10, 10, 10, 5))()
clf.load_weights(r'nn3_final.h5')

with open('/trainHistoryDict', "rb") as file_pi:
    history3 = pickle.load(file_pi)

print(r'test_acc: ', clf.evaluate(X_test, to_categorical(y_test, num_classes=5)))
print(r'train_acc: ', clf.evaluate(X_train, to_categorical(y_train, num_classes=5)))

# draw the predictions and the actual status
y_prob = clf.predict(X_test)
y_pred = [np.argmax(y) for y in y_prob]
plt.plot(range(0, len(y_test), 1), y_test, 's', label="Actual warpage status", markersize=5)
plt.plot(range(0, len(y_pred), 1), y_pred, 'o', label="Predicted warpage status", markersize=5)
plt.legend(loc='best')
plt.xlabel(r'Testing experimental samples')
plt.ylabel(r'Warpage status labels')
plt.title(r'accuracy: 97.53%')
plt.show()

y_prob = clf.predict(X_train)
y_pred = [np.argmax(y) for y in y_prob]
plt.plot(range(0, len(y_train), 1), y_train, 's', label="Actual warpage status", markersize=5)
plt.plot(range(0, len(y_pred), 1), y_pred, 'o', label="Predicted warpage status", markersize=5)
plt.legend(loc='best')
plt.xlabel(r'Training experimental samples')
plt.ylabel(r'Warpage status labels')
plt.title(r'accuracy: 98.74%')
plt.show()

# draw the probability
y_predict = clf.predict(X_test)

sns.set(style="whitegrid")
plot = sns.distplot(a=y_predict[:, 0], bins=10)
plot.set(xlabel='Probability', ylabel='Instances', title='Critical')
plt.show()

sns.set(style="whitegrid")
plot = sns.distplot(a=y_predict[:, 1], bins=10)
plot.set(xlabel='Probability', ylabel='Instances', title='Warning')
plt.show()

sns.set(style="whitegrid")
plot = sns.distplot(a=y_predict[:, 2], bins=10)
plot.set(xlabel='Probability', ylabel='Instances', title='Caution')
plt.show()

sns.set(style="whitegrid")
plot = sns.distplot(a=y_predict[:, 3], bins=10)
plot.set(xlabel='Probability', ylabel='Instances', title='Acceptable')
plt.show()

sns.set(style="whitegrid")
plot = sns.distplot(a=y_predict[:, 4], bins=10)
plot.set(xlabel='Probability', ylabel='Instances', title='Safe')
plt.show()

# Confusion matrix plot ##
# Get the predictions
val_pred_DNN3 = np.argmax(clf.predict(X_test), axis=-1)

print(classification_report(y_test,val_pred_DNN3))

# Calculate the confusion matrix
cm = confusion_matrix(y_test, val_pred_DNN3)
print(cm)
display = ConfusionMatrixDisplay(cm)
display.plot()
plt.grid(False)
plt.show()

# Other option for confusion matrix plot
fig, ax = plt.subplots(figsize=(7.5, 7.5))
ax.matshow(cm, cmap=plt.cm.Blues, alpha=0.3)
for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        ax.text(x=j, y=i, s=cm[i, j], va='center', ha='center', size='xx-large')

plt.xlabel('Predictions', fontsize=18)
plt.ylabel('Actuals', fontsize=18)
plt.title('Confusion matrix', fontsize=18)
plt.show()

##   Plotting accuracy and losses versus epoch  ##

# list all data in history
print(history3.keys())
# summarize history for accuracy
plt.plot(history3['accuracy'])
plt.plot(history3['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='lower right')
plt.show()
# summarize history for loss
plt.plot(history3['loss'])
plt.plot(history3['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper right')
plt.show()

